void analyze(TreeNode * t);
void semantic_error(int linha, char * lexema);
int verificaTipo(TreeNode * t);
